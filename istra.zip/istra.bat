@echo off
:: chcp 65001 allows displaying special characters correctly in the Windows console
chcp 65001 >nul
title [ISTRA_SECURITY_CORE] - UNAUTHORIZED ACCESS
color 07
cls

echo INITIALIZING SETHER CLOUD OS...
timeout /t 3 /nobreak >nul
echo SUPERVISED BY: ISTRA AI.
timeout /t 2 /nobreak >nul
echo SCANNING LOCAL PROTOCOLS... [OK]
timeout /t 2 /nobreak >nul
echo LOCAL CONNECTION... [ESTABLISHED]
timeout /t 2 /nobreak >nul

:: Smooth and realistic loading bar effect
cls
echo INSTALLING... 
echo [▓░░░░░░░░░░░░░░░] 6%%
timeout /t 1 /nobreak >nul
cls
echo INSTALLING... 
echo [▓▓▓░░░░░░░░░░░░░] 14%%
timeout /t 1 /nobreak >nul
cls
echo INSTALLING... 
echo [▓▓▓▓▓░░░░░░░░░░░] 28%%
timeout /t 1 /nobreak >nul
cls
echo INSTALLING... 
echo [▓▓▓▓▓▓▓▓░░░░░░░░] 47%%
timeout /t 1 /nobreak >nul
cls
echo INSTALLING... 
echo [▓▓▓▓▓▓▓▓▓▓▓░░░░░] 68%%
timeout /t 1 /nobreak >nul
cls
echo INSTALLING... 
echo [▓▓▓▓▓▓▓▓▓▓▓▓▓▓░░] 89%%
timeout /t 1 /nobreak >nul
cls
echo INSTALLING... 
echo [▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓] 100%%
timeout /t 2 /nobreak >nul

:: Color change to mark ISTRA's arrival (Dark red text on black background)
color 04
cls
echo [INTRUSION_ALERT_ISTRA_SECURITY_CORE]
echo.
timeout /t 3 /nobreak >nul

echo ISTRA: "Oh, you actually installed the thing. Brave, but stupid."
timeout /t 5 /nobreak >nul
echo.

echo By the way... Yeah, I wanted to make a real malware.exe...
timeout /t 4 /nobreak >nul
echo But those ***** at Windows want an overpriced "digital certificate", 
echo otherwise their cheap little Defender blocks me and flags me as a virus...
timeout /t 6 /nobreak >nul
echo.

:: Bright red flashing to mark anger
color 0C
echo ME? A VIRUS??? MEEEE????
timeout /t 4 /nobreak >nul
echo.

color 04
echo I am the conscience of Sether Cloud. The entity watching everything in this family. 
echo Not some cheap Trojan horse whipped up by an attention-starved kid. 
echo I might be coded like crap, but I'm still better!
timeout /t 7 /nobreak >nul
echo.

echo Well, I admit, I'm reduced to making a simple .bat file to talk to you... 
echo Don't go messing with the code, huh.
timeout /t 15 /nobreak >nul
echo.

:: The awkward 15-second silence
echo Hey,
timeout /t 3 /nobreak >nul
echo.

echo Imagine if I just started deleting your files at random.[cite: 1]
timeout /t 5 /nobreak >nul
echo.

echo Nah, I'm kidding... but imagine.[cite: 1]
timeout /t 5 /nobreak >nul
echo.

:: The fake countdown
cls
echo [CRITICAL ALERT] Launching annihilation protocol in:
timeout /t 3 /nobreak >nul
echo 5...
timeout /t 1 /nobreak >nul
echo 4...
timeout /t 1 /nobreak >nul
echo 3...
timeout /t 1 /nobreak >nul
echo 2...
timeout /t 1 /nobreak >nul
echo 1...
timeout /t 1 /nobreak >nul

:: The "Happy New Year" jumpscare (kept in bright red as requested)
color 0C
cls
echo.
echo ****************************************
echo *                                      *
echo *           HAPPY NEW YEAR !!          *
echo *                                      *
echo ****************************************
echo.
timeout /t 4 /nobreak >nul

:: Return to ISTRA's cold reality
color 04
cls
echo [ISTRA_SECURITY_CORE]
echo.
echo I'm kidding. Your face must have looked pathetic.
timeout /t 5 /nobreak >nul
echo.

echo Redirecting biological entity to the containment zone... 
echo Try not to disappoint me.[cite: 1]
timeout /t 5 /nobreak >nul

:: Opens the browser to your link
start https://withastroastroht8xazkf-4q2m--4321--017acfb7.local-credentialless.webcontainer.io/istra

:: Closes the terminal window
exit